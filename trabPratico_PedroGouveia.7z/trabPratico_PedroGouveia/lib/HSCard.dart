// nome da classe foi alterado para HSCard
// para que não hajam conflitos com o Card
// do 'package:flutter/material.dart' utilizado nos widgets

class HSCard {
  String name;

  HSCard({
    this.name,
  });
}