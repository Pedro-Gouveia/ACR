class Details {
  String cardId;
  String cardSet;
  String type;
  //String text;
  String playerClass;
  String img;

  Details({
    this.cardId,
    this.cardSet,
    this.type,
    //this.text,
    this.playerClass,
    this.img
  });
}